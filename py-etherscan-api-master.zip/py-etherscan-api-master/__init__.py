__author__ = 'Corey Petty'
name = "py-etherscan-api"